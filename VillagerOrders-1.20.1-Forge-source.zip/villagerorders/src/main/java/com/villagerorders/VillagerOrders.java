package com.villagerorders;

import com.villagerorders.network.ModNetwork;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Villager Orders - give simple orders to any villager:
 * Follow Me / Stay Here / Hide From Monsters / Back To Normal.
 */
@Mod(VillagerOrders.MOD_ID)
public class VillagerOrders {
    public static final String MOD_ID = "villagerorders";

    public VillagerOrders() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
