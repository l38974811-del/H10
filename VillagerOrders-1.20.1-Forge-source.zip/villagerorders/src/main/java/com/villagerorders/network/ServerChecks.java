package com.villagerorders.network;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.Villager;

import javax.annotation.Nullable;

/** Validation shared by the packets that arrive on the server (never trust the client). */
final class ServerChecks {
    private static final double MAX_DISTANCE_SQR = 8.0D * 8.0D;

    private ServerChecks() {}

    @Nullable
    static Villager findVillager(ServerPlayer player, int entityId) {
        Entity entity = player.level().getEntity(entityId);
        if (entity instanceof Villager villager
                && villager.isAlive()
                && player.distanceToSqr(villager) <= MAX_DISTANCE_SQR) {
            return villager;
        }
        return null;
    }
}
