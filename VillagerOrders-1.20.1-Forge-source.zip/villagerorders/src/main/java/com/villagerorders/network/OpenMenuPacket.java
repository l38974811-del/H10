package com.villagerorders.network;

import com.villagerorders.Order;
import com.villagerorders.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> Client: open the order menu for this villager (and tell it the current order). */
public record OpenMenuPacket(int entityId, int orderId) {

    public static void encode(OpenMenuPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeVarInt(msg.orderId);
    }

    public static OpenMenuPacket decode(FriendlyByteBuf buf) {
        return new OpenMenuPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(OpenMenuPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.openMenu(msg.entityId, Order.byId(msg.orderId))));
        context.setPacketHandled(true);
    }
}
