package com.villagerorders.network;

import com.villagerorders.Order;
import com.villagerorders.server.OrderManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> Server: apply this order to the villager. */
public record SetOrderPacket(int entityId, int orderId) {

    public static void encode(SetOrderPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeVarInt(msg.orderId);
    }

    public static SetOrderPacket decode(FriendlyByteBuf buf) {
        return new SetOrderPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(SetOrderPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;
            Villager villager = ServerChecks.findVillager(player, msg.entityId);
            if (villager == null) return;

            Order order = Order.byId(msg.orderId);
            OrderManager.setOrder(villager, order, player);
            player.displayClientMessage(
                    Component.translatable(order.messageKey(), villager.getDisplayName()), true);
        });
        context.setPacketHandled(true);
    }
}
