package com.villagerorders.network;

import com.villagerorders.VillagerOrders;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(VillagerOrders.MOD_ID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, RequestMenuPacket.class,
                RequestMenuPacket::encode, RequestMenuPacket::decode, RequestMenuPacket::handle);
        CHANNEL.registerMessage(id++, OpenMenuPacket.class,
                OpenMenuPacket::encode, OpenMenuPacket::decode, OpenMenuPacket::handle);
        CHANNEL.registerMessage(id++, SetOrderPacket.class,
                SetOrderPacket::encode, SetOrderPacket::decode, SetOrderPacket::handle);
    }
}
