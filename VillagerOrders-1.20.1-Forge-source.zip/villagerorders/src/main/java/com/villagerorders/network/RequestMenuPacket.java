package com.villagerorders.network;

import com.villagerorders.server.OrderManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

/** Client -> Server: "I shift-clicked this villager, please open the menu." */
public record RequestMenuPacket(int entityId) {

    public static void encode(RequestMenuPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
    }

    public static RequestMenuPacket decode(FriendlyByteBuf buf) {
        return new RequestMenuPacket(buf.readVarInt());
    }

    public static void handle(RequestMenuPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;
            Villager villager = ServerChecks.findVillager(player, msg.entityId);
            if (villager == null) return;
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new OpenMenuPacket(villager.getId(), OrderManager.getOrder(villager).id));
        });
        context.setPacketHandled(true);
    }
}
