package com.villagerorders;

import net.minecraftforge.common.ForgeConfigSpec;

/** Client-side option, saved in config/villagerorders-client.toml */
public final class ClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_SNEAK;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("menu");
        REQUIRE_SNEAK = builder
                .comment("true  = Shift + Right-click on a villager opens the order menu (normal Right-click still opens trading).",
                         "false = a plain Right-click opens the order menu (you will NOT be able to trade by Right-click).")
                .define("requireSneak", true);
        builder.pop();
        SPEC = builder.build();
    }

    private ClientConfig() {}
}
