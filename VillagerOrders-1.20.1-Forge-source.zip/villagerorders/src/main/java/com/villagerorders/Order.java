package com.villagerorders;

import net.minecraft.resources.ResourceLocation;

/** The orders a villager can be given. NONE = vanilla behaviour. */
public enum Order {
    NONE(0, "normal"),
    FOLLOW(1, "follow"),
    STAY(2, "stay"),
    HIDE(3, "hide");

    public final int id;
    public final String key;

    Order(int id, String key) {
        this.id = id;
        this.key = key;
    }

    public String buttonKey()  { return "gui.villagerorders.button." + key; }
    public String tooltipKey() { return "gui.villagerorders.tooltip." + key; }
    public String stateKey()   { return "gui.villagerorders.state." + key; }
    public String messageKey() { return "message.villagerorders." + key; }

    public ResourceLocation icon() {
        return new ResourceLocation(VillagerOrders.MOD_ID, "textures/gui/icon_" + key + ".png");
    }

    public static Order byId(int id) {
        for (Order order : values()) {
            if (order.id == id) return order;
        }
        return NONE;
    }
}
