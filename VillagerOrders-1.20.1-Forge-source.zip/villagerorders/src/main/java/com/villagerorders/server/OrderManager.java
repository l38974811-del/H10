package com.villagerorders.server;

import com.villagerorders.Order;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Server-side logic of the orders.
 *
 * How it keeps the villager's vanilla AI intact:
 *  - Nothing in the villager's brain/AI is replaced or modified.
 *  - The order is only stored in the villager's own NBT ("ForgeData") so it survives restarts.
 *  - At the END of every level tick (after the villager's own brain has run) we simply
 *    override the walking target of villagers that have an active order.
 *  - "Back To Normal" removes the order, so the vanilla brain is in full control again.
 */
public final class OrderManager {
    private static final String ROOT = "VillagerOrders";
    private static final String KEY_ORDER = "Order";
    private static final String KEY_OWNER = "Owner";

    // Follow
    private static final double FOLLOW_START_SQR = 4.0D * 4.0D;
    private static final double FOLLOW_STOP_SQR = 2.5D * 2.5D;
    private static final double FOLLOW_TELEPORT_SQR = 24.0D * 24.0D;
    // Hide
    private static final double THREAT_RADIUS = 14.0D;
    private static final int SAFE_TICKS_BEFORE_NORMAL = 200;      // 10 seconds without monsters
    private static final double MAX_HOME_DIST_SQR = 48.0D * 48.0D;

    /** Villagers that currently have an active order (server thread only). */
    private static final Map<Villager, OrderState> ACTIVE = new HashMap<>();

    private OrderManager() {}

    private static final class OrderState {
        final Order order;
        @Nullable final UUID owner;
        int cooldown = 0;
        boolean hiding = false;
        int safeTicks = 0;
        Vec3 threatPos = Vec3.ZERO;

        OrderState(Order order, @Nullable UUID owner) {
            this.order = order;
            this.owner = owner;
        }
    }

    // ------------------------------------------------------------------ storage

    public static Order getOrder(Villager villager) {
        CompoundTag root = villager.getPersistentData().getCompound(ROOT);
        return Order.byId(root.getByte(KEY_ORDER));
    }

    @Nullable
    private static UUID getOwner(Villager villager) {
        CompoundTag root = villager.getPersistentData().getCompound(ROOT);
        return root.hasUUID(KEY_OWNER) ? root.getUUID(KEY_OWNER) : null;
    }

    public static void setOrder(Villager villager, Order order, ServerPlayer commander) {
        ACTIVE.remove(villager);
        CompoundTag data = villager.getPersistentData();

        if (order == Order.NONE) {
            data.remove(ROOT);
            stopMoving(villager);          // the vanilla brain plans from scratch
            return;
        }

        CompoundTag tag = new CompoundTag();
        tag.putByte(KEY_ORDER, (byte) order.id);
        tag.putUUID(KEY_OWNER, commander.getUUID());
        data.put(ROOT, tag);

        ACTIVE.put(villager, new OrderState(order, commander.getUUID()));
        if (order == Order.FOLLOW && villager.isSleeping()) {
            villager.stopSleeping();
        }
        stopMoving(villager);
    }

    // ------------------------------------------------------------------ lifecycle

    public static void onVillagerJoined(Villager villager) {
        Order order = getOrder(villager);
        if (order != Order.NONE) {
            ACTIVE.put(villager, new OrderState(order, getOwner(villager)));
        }
    }

    public static void onEntityLeft(Entity entity) {
        if (entity instanceof Villager villager) {
            ACTIVE.remove(villager);
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }

    // ------------------------------------------------------------------ ticking

    /** Called at the END of every server level tick, i.e. after the villagers' own AI. */
    public static void tick(ServerLevel level) {
        if (ACTIVE.isEmpty()) return;

        Iterator<Map.Entry<Villager, OrderState>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Villager, OrderState> entry = it.next();
            Villager villager = entry.getKey();
            if (villager.isRemoved() || !villager.isAlive()) {
                it.remove();
                continue;
            }
            if (villager.level() != level) continue;

            OrderState state = entry.getValue();
            switch (state.order) {
                case FOLLOW -> tickFollow(level, villager, state);
                case STAY -> tickStay(villager);
                case HIDE -> tickHide(level, villager, state);
                default -> { }
            }
        }
    }

    // ------------------------------------------------------------------ FOLLOW

    private static void tickFollow(ServerLevel level, Villager villager, OrderState state) {
        Player owner = state.owner == null ? null : level.getPlayerByUUID(state.owner);
        // Owner offline / dead / in another dimension -> vanilla behaviour until they are back.
        if (owner == null || !owner.isAlive() || owner.isSpectator()) return;

        if (villager.isTrading()) {
            villager.getNavigation().stop();
            return;
        }
        if (villager.isSleeping()) {
            villager.stopSleeping();
        }

        takeOverMovement(villager);
        PathNavigation nav = villager.getNavigation();
        double distSqr = villager.distanceToSqr(owner);

        if (distSqr > FOLLOW_TELEPORT_SQR) {
            teleportNear(level, villager, owner);
            return;
        }

        villager.getLookControl().setLookAt(owner, 10.0F, (float) villager.getMaxHeadXRot());

        if (distSqr > FOLLOW_START_SQR) {
            if (--state.cooldown <= 0) {
                state.cooldown = 8;
                nav.moveTo(owner, distSqr > 100.0D ? 0.95D : 0.65D);
            }
            shareNavigationPath(villager);
        } else if (distSqr < FOLLOW_STOP_SQR) {
            stopMoving(villager);
        }
    }

    private static void teleportNear(ServerLevel level, Villager villager, Player owner) {
        RandomSource random = villager.getRandom();
        for (int i = 0; i < 12; i++) {
            int dx = random.nextIntBetweenInclusive(-3, 3);
            int dz = random.nextIntBetweenInclusive(-3, 3);
            if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
            int dy = random.nextIntBetweenInclusive(-1, 1);
            BlockPos target = owner.blockPosition().offset(dx, dy, dz);
            if (canStandAt(level, villager, target)) {
                villager.moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D,
                        villager.getYRot(), villager.getXRot());
                stopMoving(villager);
                return;
            }
        }
    }

    private static boolean canStandAt(ServerLevel level, Villager villager, BlockPos pos) {
        BlockPos below = pos.below();
        BlockState floor = level.getBlockState(below);
        if (!floor.isFaceSturdy(level, below, Direction.UP) || floor.is(BlockTags.LEAVES)) return false;
        if (!level.getFluidState(pos).isEmpty()) return false;
        AABB moved = villager.getBoundingBox().move(
                pos.getX() + 0.5D - villager.getX(),
                pos.getY() - villager.getY(),
                pos.getZ() + 0.5D - villager.getZ());
        return level.noCollision(villager, moved);
    }

    // ------------------------------------------------------------------ STAY

    private static void tickStay(Villager villager) {
        if (villager.isSleeping()) return;       // let a sleeping villager keep sleeping
        stopMoving(villager);
    }

    // ------------------------------------------------------------------ HIDE

    private static void tickHide(ServerLevel level, Villager villager, OrderState state) {
        // Look for monsters twice a second (spread out between villagers).
        if ((villager.tickCount + villager.getId()) % 10 == 0) {
            LivingEntity threat = findThreat(level, villager);
            if (threat != null) {
                state.hiding = true;
                state.safeTicks = 0;
                state.threatPos = threat.position();
            } else if (state.hiding) {
                state.safeTicks += 10;
                if (state.safeTicks >= SAFE_TICKS_BEFORE_NORMAL) {
                    state.hiding = false;          // safe again -> vanilla behaviour
                    stopMoving(villager);
                    return;
                }
            }
        }
        if (!state.hiding) return;                 // no monsters around -> completely vanilla

        takeOverMovement(villager);
        if (villager.isSleeping() || villager.isTrading()) return;

        PathNavigation nav = villager.getNavigation();
        BlockPos hideSpot = findHideSpot(level, villager);

        if (hideSpot != null) {
            if (hideSpot.closerToCenterThan(villager.position(), 2.0D)) {
                stopMoving(villager);              // arrived home: stay inside
            } else {
                if (--state.cooldown <= 0) {
                    state.cooldown = 10;
                    nav.moveTo(hideSpot.getX() + 0.5D, hideSpot.getY(), hideSpot.getZ() + 0.5D, 0.9D);
                }
                shareNavigationPath(villager);
            }
        } else {
            // No home bed nearby: run away from the monsters.
            if (--state.cooldown <= 0) {
                state.cooldown = 20;
                Vec3 away = DefaultRandomPos.getPosAway(villager, 16, 7, state.threatPos);
                if (away != null) {
                    nav.moveTo(away.x, away.y, away.z, 1.0D);
                }
            }
            shareNavigationPath(villager);
        }
    }

    @Nullable
    private static BlockPos findHideSpot(ServerLevel level, Villager villager) {
        Optional<GlobalPos> home = villager.getBrain().getMemory(MemoryModuleType.HOME);
        if (home.isPresent() && home.get().dimension() == level.dimension()) {
            BlockPos pos = home.get().pos();
            if (pos.distSqr(villager.blockPosition()) <= MAX_HOME_DIST_SQR) {
                return pos;
            }
        }
        return null;
    }

    @Nullable
    private static LivingEntity findThreat(ServerLevel level, Villager villager) {
        AABB area = villager.getBoundingBox().inflate(THREAT_RADIUS, 6.0D, THREAT_RADIUS);
        List<LivingEntity> found = level.getEntitiesOfClass(LivingEntity.class, area, OrderManager::isThreat);
        LivingEntity best = null;
        double bestDist = THREAT_RADIUS * THREAT_RADIUS;
        for (LivingEntity entity : found) {
            double dist = villager.distanceToSqr(entity);
            if (dist <= bestDist) {
                bestDist = dist;
                best = entity;
            }
        }
        return best;
    }

    private static boolean isThreat(LivingEntity entity) {
        if (!(entity instanceof Enemy) || !entity.isAlive()) return false;
        // Neutral monsters (e.g. zombified piglins, endermen) only count when they are angry.
        if (entity instanceof NeutralMob neutral && !neutral.isAngry()) return false;
        return true;
    }

    // ------------------------------------------------------------------ helpers

    /** Stops the vanilla brain from choosing where to walk this tick. */
    private static void takeOverMovement(Villager villager) {
        villager.getBrain().eraseMemory(MemoryModuleType.WALK_TARGET);
    }

    /**
     * Publishes our path to the brain so the vanilla "open / close doors" behaviour
     * keeps working while the villager walks along it.
     */
    private static void shareNavigationPath(Villager villager) {
        Path path = villager.getNavigation().getPath();
        if (path != null) {
            villager.getBrain().setMemory(MemoryModuleType.PATH, path);
        } else {
            villager.getBrain().eraseMemory(MemoryModuleType.PATH);
        }
    }

    private static void stopMoving(Villager villager) {
        villager.getNavigation().stop();
        villager.getBrain().eraseMemory(MemoryModuleType.WALK_TARGET);
        villager.getBrain().eraseMemory(MemoryModuleType.PATH);
    }
}
