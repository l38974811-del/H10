package com.villagerorders.client;

import com.villagerorders.Order;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.Villager;

/** Client-only helpers (only ever called through DistExecutor on the client). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openMenu(int entityId, Order currentOrder) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity entity = mc.level.getEntity(entityId);
        if (entity instanceof Villager) {
            mc.setScreen(new VillagerOrderScreen(entityId, currentOrder));
        }
    }
}
