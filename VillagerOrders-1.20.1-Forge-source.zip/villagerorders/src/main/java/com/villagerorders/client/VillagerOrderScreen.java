package com.villagerorders.client;

import com.villagerorders.Order;
import com.villagerorders.network.ModNetwork;
import com.villagerorders.network.SetOrderPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.Villager;

import java.util.Locale;

/**
 * The order menu: villager name, health, and four buttons - each with an icon
 * on the left that shows what the order is for (hover a button for a longer explanation).
 */
public class VillagerOrderScreen extends Screen {
    private static final int PANEL_W = 220;
    private static final int PANEL_H = 218;
    private static final int ROW_H = 34;
    private static final int FIRST_ROW_Y = 76;
    private static final ResourceLocation VANILLA_ICONS = new ResourceLocation("textures/gui/icons.png");

    private static final Order[] ROWS = {Order.FOLLOW, Order.STAY, Order.HIDE, Order.NONE};

    private final int villagerId;
    private final Order currentOrder;
    private int left;
    private int top;

    public VillagerOrderScreen(int villagerId, Order currentOrder) {
        super(Component.translatable("gui.villagerorders.title"));
        this.villagerId = villagerId;
        this.currentOrder = currentOrder;
    }

    @Override
    protected void init() {
        this.left = (this.width - PANEL_W) / 2;
        this.top = (this.height - PANEL_H) / 2;

        int y = this.top + FIRST_ROW_Y;
        for (Order order : ROWS) {
            Button button = Button.builder(Component.translatable(order.buttonKey()), b -> choose(order))
                    .bounds(this.left + 52, y + 4, 156, 24)
                    .tooltip(Tooltip.create(Component.translatable(order.tooltipKey())))
                    .build();
            // The order that is already active (or "normal" when nothing is active) cannot be re-selected.
            button.active = order != this.currentOrder;
            this.addRenderableWidget(button);
            y += ROW_H;
        }
    }

    private void choose(Order order) {
        ModNetwork.CHANNEL.sendToServer(new SetOrderPacket(this.villagerId, order.id));
        this.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;   // the world keeps running while the menu is open
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        Entity entity = mc.level == null ? null : mc.level.getEntity(this.villagerId);
        if (!(entity instanceof Villager villager) || !villager.isAlive()
                || mc.player == null || mc.player.distanceToSqr(villager) > 144.0D) {
            this.onClose();
            return;
        }

        this.renderBackground(g);

        // panel
        g.fill(this.left - 1, this.top - 1, this.left + PANEL_W + 1, this.top + PANEL_H + 1, 0xFF000000);
        g.fill(this.left, this.top, this.left + PANEL_W, this.top + PANEL_H, 0xFF555555);
        g.fill(this.left + 2, this.top + 2, this.left + PANEL_W - 2, this.top + PANEL_H - 2, 0xFF2E2E2E);

        // name
        g.drawCenteredString(this.font, villager.getDisplayName(), this.left + PANEL_W / 2, this.top + 9, 0xFFFFFF);

        // health (hearts + numbers)
        float health = villager.getHealth();
        float max = villager.getMaxHealth();
        int hearts = Math.min(20, Math.max(1, (int) Math.ceil(max / 2.0F)));
        int perRow = Math.min(hearts, 10);
        drawHearts(g, health, hearts, this.left + (PANEL_W - (perRow * 8 + 1)) / 2, this.top + 23);
        g.drawCenteredString(this.font,
                Component.translatable("gui.villagerorders.health", fmt(health), fmt(max)),
                this.left + PANEL_W / 2, this.top + (hearts > 10 ? 45 : 36), 0xFF5555);

        // current order
        g.drawCenteredString(this.font,
                Component.translatable("gui.villagerorders.current",
                        Component.translatable(this.currentOrder.stateKey())),
                this.left + PANEL_W / 2, this.top + 57, 0xFFD966);

        // separator
        g.fill(this.left + 10, this.top + 70, this.left + PANEL_W - 10, this.top + 71, 0xFF777777);

        // buttons (+ their tooltips)
        super.render(g, mouseX, mouseY, partialTick);

        // icons: one picture beside each order that shows its purpose
        int y = this.top + FIRST_ROW_Y;
        for (Order order : ROWS) {
            g.blit(order.icon(), this.left + 12, y, 0, 0, 32, 32, 32, 32);
            y += ROW_H;
        }
    }

    private void drawHearts(GuiGraphics g, float health, int hearts, int x, int y) {
        for (int i = 0; i < hearts; i++) {
            int hx = x + (i % 10) * 8;
            int hy = y + (i / 10) * 10;
            g.blit(VANILLA_ICONS, hx, hy, 16, 0, 9, 9);          // empty heart container
            float hp = health - i * 2.0F;
            if (hp >= 2.0F) {
                g.blit(VANILLA_ICONS, hx, hy, 52, 0, 9, 9);      // full heart
            } else if (hp >= 1.0F) {
                g.blit(VANILLA_ICONS, hx, hy, 61, 0, 9, 9);      // half heart
            }
        }
    }

    private static String fmt(float value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }
}
