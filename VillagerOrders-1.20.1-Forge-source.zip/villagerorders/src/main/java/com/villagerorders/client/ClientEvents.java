package com.villagerorders.client;

import com.villagerorders.ClientConfig;
import com.villagerorders.VillagerOrders;
import com.villagerorders.network.ModNetwork;
import com.villagerorders.network.RequestMenuPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = VillagerOrders.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    /**
     * Shift + Right-click on a villager opens the order menu.
     * A normal Right-click is left alone, so trading works exactly like vanilla.
     */
    @SubscribeEvent
    public static void onInteractVillager(PlayerInteractEvent.EntityInteract event) {
        if (!event.getLevel().isClientSide()) return;
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(event.getTarget() instanceof Villager villager)) return;

        Player player = event.getEntity();
        if (player.isSpectator()) return;
        if (ClientConfig.REQUIRE_SNEAK.get() && !player.isShiftKeyDown()) return;
        if (player.getMainHandItem().is(Items.NAME_TAG)) return;       // keep naming villagers possible

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        ModNetwork.CHANNEL.sendToServer(new RequestMenuPacket(villager.getId()));
    }
}
